@extends('layouts.main')
@section('title','Perfil de usuario')
@section('header','Perfil de usuario')
@section('nav')
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li>
@endsection
@section('content.profile')

@endsection
