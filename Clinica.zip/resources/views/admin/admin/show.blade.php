@extends('layouts.admin')
@section('title','Panel administrador')
@section('dropdown')
{{--  <a class="dropdown-item has-icon" href="#"><i class="far fa-heart"></i> Action</a>  --}}
@endsection
@section('breadcrumb')
{{--  <li class="breadcrumb-item active">@yield('title')</li>  --}}
@endsection
@section('content')
<div class="card">
    <div class="card-header">
        <h4>Panel de administración</h4>
    </div>
    <div class="card-body">

    </div>
</div>
@endsection
