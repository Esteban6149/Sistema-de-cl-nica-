<?php
    return [
        'check_in',
        'scholarship'
    ];