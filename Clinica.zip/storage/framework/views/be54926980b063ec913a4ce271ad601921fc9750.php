
<?php $__env->startSection('title','Detalles de Especialidad '.$speciality->name); ?>
<?php $__env->startSection('dropdown'); ?>



<a class="dropdown-item has-icon" href="<?php echo e(route('backoffice.speciality.edit', $speciality)); ?>"><i class="far fa-heart"></i> Editar</a> 

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.speciality.index')); ?>">Especialidades</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    
    <div class="col-12 col-md-6 col-lg-6">
        <div class="card">
            <div class="card-header">
                <h4><?php echo e($speciality->name); ?></h4>
            </div>
            <div class="card-body">
                <p><strong>Nombre: </strong><?php echo e($speciality->name); ?></p>
            </div>
            <div class="card-footer text-right">
                <?php echo Form::open(['route'=>['backoffice.speciality.destroy',$speciality], 'method'=>'DELETE',
                'class'=>'formulario-eliminar']); ?>

                <button class="btn btn-secondary mr-2" type="submit">Eliminar</button>
                <a href="<?php echo e(route('backoffice.speciality.edit', $speciality)); ?>" class="btn btn-primary"
                    type="reset">Editar</a>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

    <div class="col-12 col-md-6 col-lg-6">
        <div class="card">
            <div class="card-header">
                <h4>Permisos</h4>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Correo</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($user->id); ?></th>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <a href="<?php echo e(route('backoffice.users.show', $user)); ?>"
                                    class="btn btn-icon btn-secondary"><i class="fas fa-eye"></i></a>

                                <a href="<?php echo e(route('backoffice.users.edit', $user)); ?>" class="btn btn-icon btn-primary"><i
                                        class="far fa-edit"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3">No hay médicos registrados</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/speciality/show.blade.php ENDPATH**/ ?>