<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo Html::style('adminelt/plugins/fontawesome-free/css/all.min.css'); ?>

    <?php echo Html::style('adminelt/dist/css/adminlte.min.css'); ?>

    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="hold-transition layout-top-nav">
    <div class="wrapper">

        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
            <div class="container">
                <a href="adminelt/index3.html" class="navbar-brand">
                    
                    <span class="brand-text font-weight-light">Sistema de clínica</span>
                </a>

                <button class="navbar-toggler order-1" type="button" data-toggle="collapse"
                    data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse order-3" id="navbarCollapse">
                    <!-- Left navbar links -->
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a href="<?php echo e(route('welcome')); ?>" class="nav-link">Inicio</a>

                        </li>
                        <?php echo $__env->yieldContent('nav'); ?>

                        <?php if(auth()->user()->has_any_role([config('app.admin_role'),config('app.secretary_role'),('app.doctor_role')])): ?>
                                <a href="<?php echo e(route('backoffice.admin.show')); ?>" class="nav-link">Panel administrador</a>
                            </li>
                        <?php endif; ?>

                        

                        
                    </ul>

                    <!-- SEARCH FORM -->
                    
                </div>

                <!-- Right navbar links -->
                <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
                    <!-- Messages Dropdown Menu -->
                    
                    <!-- Notifications Dropdown Menu -->
                    

                </ul>
            </div>
        </nav>
        <!-- /.navbar -->

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container">


                    <div class="content-wrapper">
                        <section class="content">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="card card-primary card-outline">
                                            <div class="card-body box-profile">
                                                <div class="text-center">
                                                    <img class="profile-user-img img-fluid img-circle"
                                                        src="<?php echo asset('adminelt/dist/img/user4-128x128.jpg'); ?>"
                                                        alt="User profile picture">
                                                </div>

                                                <h3 class="profile-username text-center"><?php echo $__env->yieldContent('name.user'); ?></h3>

                                                

                                                <ul class="list-group list-group-unbordered mb-3">
                                                    <li class="list-group-item">
                                                        <b>Edad</b> <a class="float-right"><?php echo $__env->yieldContent('dob.user'); ?></a>
                                                    </li>
                                                    <li class="list-group-item">
                                                        <b>Email</b> <a class="float-right"><?php echo $__env->yieldContent('email.user'); ?></a>
                                                    </li>
                                                    <li class="list-group-item">
                                                        <b>Miembro desde</b> <a class="float-right"><?php echo $__env->yieldContent('date.user'); ?></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php echo $__env->make('frontoffice.user._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="card">
                                            <div class="card-header p-2">
                                                <h5 class="card-title"><?php echo $__env->yieldContent('header'); ?></h5>
                                            </div>
                                            <div class="card-body">
                                                <div class="tab-content">
                                                    <?php echo $__env->yieldContent('content.profile'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>


                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->

            <!-- /.content -->
        </div>
        <footer class="main-footer">
            <!-- To the right -->
            <div class="float-right d-none d-sm-inline">
                Anything you want
            </div>
            <!-- Default to the left -->
            <strong>Copyright &copy; 2014-2019 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights
            reserved.
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->

    <!-- jQuery -->
    <?php echo Html::script('adminelt/plugins/jquery/jquery.min.js'); ?>

    <!-- Bootstrap 4 -->
    <?php echo Html::script('adminelt/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>

    <!-- AdminLTE App -->
    <?php echo Html::script('adminelt/dist/js/adminlte.min.js'); ?>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Clinica\resources\views/layouts/main.blade.php ENDPATH**/ ?>