<div class="card card-primary">
    
    <!-- /.card-header -->
    <div class="list-group" id="list-tab" role="tablist">
        <a class="list-group-item list-group-item-action <?php echo active_class(route('frontoffice.user.profile')); ?>"
            href="<?php echo e(route('frontoffice.user.profile')); ?>">
            Perfil
        </a>
        <?php if(auth()->user()->has_role(config('app.patient_role'))): ?>
        <a class="list-group-item list-group-item-action <?php echo active_class(route('frontoffice.patient.schedule')); ?>"
            href="<?php echo e(route('frontoffice.patient.schedule')); ?>">
            Agendar cita
        </a>
        <a class="list-group-item list-group-item-action <?php echo active_class(route('frontoffice.patient.appointments')); ?>" href="<?php echo e(route('frontoffice.patient.appointments')); ?>">
            Mis citas
        </a>
        <a class="list-group-item list-group-item-action <?php echo active_class(route('frontoffice.patient.prescriptions')); ?>" href="<?php echo e(route('frontoffice.patient.prescriptions')); ?>">
            Recetas
        </a>
        <?php endif; ?>

        <a class="list-group-item list-group-item-action <?php echo active_class(route('frontoffice.patient.invoices')); ?>" href="<?php echo e(route('frontoffice.patient.invoices')); ?>">
            Facturación
        </a>
        <a class="list-group-item list-group-item-action <?php echo active_class(route('frontoffice.user.edit', [auth()->user()])); ?>" href="<?php echo e(route('frontoffice.user.edit', [auth()->user(), 'view=frontoffice'])); ?>">
            Editar perfil
        </a>
        <a class="list-group-item list-group-item-action <?php echo active_class(route('frontoffice.user.edit_password')); ?>" href="<?php echo e(route('frontoffice.user.edit_password')); ?>">
            Modificar contraseña
        </a>
    </div>
    <!-- /.card-body -->
</div>
<?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/user/_menu.blade.php ENDPATH**/ ?>