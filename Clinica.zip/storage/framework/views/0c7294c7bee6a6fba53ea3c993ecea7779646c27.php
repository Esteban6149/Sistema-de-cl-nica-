
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('name.user', $user->name); ?>
<?php $__env->startSection('dob.user', $user->age()); ?>
<?php $__env->startSection('email.user', $user->email); ?>
<?php $__env->startSection('date.user', $user->created_at->diffForHumans()); ?>
<?php $__env->startSection('title','Recetas'); ?>
<?php $__env->startSection('header','Recetas'); ?>
<?php $__env->startSection('nav'); ?>
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content.profile'); ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Historial de recetas</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <?php echo $__env->make('includes.user.patient.invoice_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
        
    </div>
</div>

<?php echo $__env->make('includes.user.patient.invoice_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

    <?php echo $__env->make('includes.user.patient.invoice_foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/patient/invoices.blade.php ENDPATH**/ ?>