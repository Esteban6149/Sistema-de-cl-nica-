
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('name.user', $user->name); ?>
<?php $__env->startSection('dob.user', $user->age()); ?>
<?php $__env->startSection('email.user', $user->email); ?>
<?php $__env->startSection('date.user', $user->created_at->diffForHumans()); ?>
<?php $__env->startSection('title','Modificar contraseña'); ?>
<?php $__env->startSection('header','Modificar contraseña'); ?>
<?php $__env->startSection('nav'); ?>
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content.profile'); ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Modificar contraseña</h3>
    </div>
    <?php echo Form::model($user, ['route'=>['frontoffice.user.change_password'],'method'=>'PUT']); ?>

    <div class="card-body">

        <div class="from-group">
            <?php echo Form::label('old_password','Contraseña actual'); ?>

            <?php echo Form::password('old_password', ['class'=>'form-control'],array('required' => 'required')); ?>

            <?php if($errors->has('old_password')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('old_password')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="from-group">
            <?php echo Form::label('password','Nueva contraseña'); ?>

            <?php echo Form::password('password', ['class'=>'form-control'],array('required' => 'required')); ?>

            <?php if($errors->has('password')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('password')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="from-group">
            <?php echo Form::label('password_confirmation','Confirmar contraseña'); ?>

            <?php echo Form::password('password_confirmation', ['class'=>'form-control']); ?>

        </div>

    </div>
    <div class="card-footer clearfix">
        <button type="submit" class="btn btn-primary float-right"><i class="far fa-paper-plane"></i>
            Actualizar</button>
    </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('otika/assets/bundles/jquery-ui/jquery-ui.min.js'); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php if(session('guardado') == 'ok'): ?>
<script>
    Swal.fire({

        icon: 'success',
        title: 'Contraseña actualizada correctamente',
        showConfirmButton: false,
        timer: 1200
    })

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/user/edit_password.blade.php ENDPATH**/ ?>