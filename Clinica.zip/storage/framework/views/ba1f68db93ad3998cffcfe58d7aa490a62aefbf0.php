
<?php $__env->startSection('title','Detalles de permiso'); ?>
<?php $__env->startSection('dropdown'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.permissions.index')); ?>">Permisos</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4>Detalles de permiso <?php echo e($permission->name); ?></h4>
      </div>
        <div class="card-body">
            <p><strong>Nombre: </strong><?php echo e($permission->name); ?></p>
            <p><strong>Slug: </strong><?php echo e($permission->slug); ?></p>
            <p><strong>Rol al que pertenece: </strong><?php echo e($permission->role->name); ?></p>
            <p><strong>Descripción: </strong><?php echo e($permission->description); ?></p>
        </div>
        <div class="card-footer text-right">
            <a href="<?php echo e(route('backoffice.permissions.index')); ?>" class="btn btn-secondary" type="reset">Regresar</a>
        </div>
    </div>
</div>
<h1></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/permission/show.blade.php ENDPATH**/ ?>