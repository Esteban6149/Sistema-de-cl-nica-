
<?php $__env->startSection('name.user', $user->name); ?>
<?php $__env->startSection('dob.user', $user->age()); ?>
<?php $__env->startSection('email.user', $user->email); ?>
<?php $__env->startSection('date.user', $user->created_at->diffForHumans()); ?>
<?php $__env->startSection('title','Perfil de usuario'); ?>
<?php $__env->startSection('header','Perfil de usuario'); ?>
<?php $__env->startSection('nav'); ?>
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content.profile'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/user/profile.blade.php ENDPATH**/ ?>