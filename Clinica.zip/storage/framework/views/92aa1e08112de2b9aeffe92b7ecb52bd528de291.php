<table class="table ">
    <thead>
        <tr>
            <th style="width: 10px">ID</th>
            <th>Concepto</th>
            
            <th>Monto</th>
            <th>Estatus</th>
            <th
            <?php if(isset($user)): ?>
                colspan="2"
            <?php endif; ?>
            >Acción</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($invoice->id); ?></td>
            <td><?php echo e($invoice->concept()); ?></td>
            
            <td><?php echo e($invoice->amount); ?></td>
            <td><?php echo e($invoice->status); ?></td>
            <td>
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default"
                data-invoice="<?php echo e($invoice->id); ?>"
                onclick="modal_invoice(this)">
                    Ver
                </button>
            </td>
            <?php if(isset($user)): ?>
                <td>
                    <a href="<?php echo e(route('backoffice.patient.invoices.edit',[$user, $invoice])); ?>">Editar</a>
                </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5">No tienes registrada ninguna factura</td>
        </tr>
        <?php endif; ?>

    </tbody>
</table><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/includes/user/patient/invoice_table.blade.php ENDPATH**/ ?>