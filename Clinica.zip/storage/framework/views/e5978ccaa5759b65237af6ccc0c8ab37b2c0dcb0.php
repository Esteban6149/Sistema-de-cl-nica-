
<?php $__env->startSection('title','Citas de '.$user->name); ?>
<?php $__env->startSection('dropdown'); ?>
<a class="dropdown-item has-icon" href="<?php echo e(route('backoffice.patient.schedule', $user)); ?>"><i class="fas fa-user-plus"></i> Agendar nueva cita</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.index')); ?>">Usuarios</a></li>

<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.show', $user)); ?>"><?php echo e($user->name); ?></a></li>

<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-9 col-md-12 col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h4>Citas de <?php echo e($user->name); ?></h4>
                <div class="card-header-form">
                    
                </div>
            </div>
            <div class="card-body">
                    <?php echo $__env->make('includes.user.patient.appointments',[
                        'update' => true
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-right">
                <nav class="d-inline-block">
                   
                </nav>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.user._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('otika/assets/bundles/jquery-ui/jquery-ui.min.js'); ?>

<!-- Page Specific JS File -->
<?php echo Html::script('otika/assets/js/page/advance-table.js'); ?>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    $('.formulario-eliminar').submit(function (e) {
        e.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        })
    });

</script>
<?php if(session('eliminar') == 'ok'): ?>
<script>
    Swal.fire(
        'Deleted!',
        'Your file has been deleted.',
        'success'
    )

</script>
<?php endif; ?>
<?php if(session('editado') == 'ok'): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Your work has been saved',
        showConfirmButton: false,
        timer: 1200
    })

</script>
<?php endif; ?>
<?php if(session('guardado') == 'ok'): ?>
<script>
    Swal.fire({

        icon: 'success',
        title: 'Your work has been saved',
        showConfirmButton: false,
        timer: 1200
    })

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/user/patient/appointment.blade.php ENDPATH**/ ?>