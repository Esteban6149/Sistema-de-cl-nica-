<table class="table table-bordered">
    <thead>
        <tr>
            <th style="width: 10px">ID</th>
            <th>Especialista</th>
            <th>Fecha</th>
            <th>Estado</th>
            <?php if($update): ?>
            <th>Acciones</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($appointment->id); ?></td>
            <td><?php echo e($appointment->doctor()->name); ?></td>
            <td><?php echo e($appointment->date->format('d/m/Y H:i')); ?></td>
            <td><?php echo e($appointment->status); ?></td>
            <?php if($update): ?>
            <td><a href="<?php echo e(route('backoffice.patient.appointments.edit', [$user, $appointment])); ?>">Editar</a></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr colspan="4">No hay citas registradas</tr>
        <?php endif; ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/includes/user/patient/appointments.blade.php ENDPATH**/ ?>