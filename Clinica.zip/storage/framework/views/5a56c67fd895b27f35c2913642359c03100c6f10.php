
<?php $__env->startSection('title','Detalles de usuario'); ?>
<?php $__env->startSection('dropdown'); ?>

<a class="dropdown-item has-icon" href="<?php echo e(route('backoffice.users.edit',$user)); ?>"><i class="fas fa-user-edit"></i>
    Editar usuario</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.index')); ?>">Usuarios</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-9 col-md-12 col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h4>Detalles de usuario <?php echo e($user->name); ?></h4>
            </div>
            <div class="card-body">
                <p><strong>Nombre: </strong><?php echo e($user->name); ?></p>
                <p><strong>Edad: </strong><?php echo e($user->age()); ?></p>
                <p><strong>Roles: </strong><?php echo e($user->list_roles()); ?></p>
                <?php if($user->has_role(config('app.doctor_role'))): ?>
                <p><strong>Especialidades: </strong><?php echo e($user->list_specialities()); ?></p>
                <?php endif; ?>
            </div>
            <div class="card-footer text-right">
                <a href="<?php echo e(route('backoffice.users.index')); ?>" class="btn btn-secondary" type="reset">Regresar</a>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.user._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('otika/assets/bundles/jquery-ui/jquery-ui.min.js'); ?>

<!-- Page Specific JS File -->
<?php echo Html::script('otika/assets/js/page/advance-table.js'); ?>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<?php if(session('guardado') == 'ok'): ?>
<script>
    Swal.fire({

        icon: 'success',
        title: 'Your work has been saved',
        showConfirmButton: false,
        timer: 1200
    })

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/user/show.blade.php ENDPATH**/ ?>