
<?php $__env->startSection('title','Importar usuarios'); ?>
<?php $__env->startSection('styles'); ?>
<?php echo Html::style('otika/assets/bundles/dropzonejs/dropzone.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dropdown'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.index')); ?>">Usuarios del sistema</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4>Seleccionar un archivo de Excel.</h4>
    </div>
    <div class="card-body">

        <form action="<?php echo e(route('backoffice.users.make_import')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="file" />
            <button class="btn btn-primary mr-1" type="submit" >Guardar</button>
        </form>
        
        
    </div>
    <div class="card-footer text-right">
        <button class="btn btn-primary mr-1" type="submit" form="mydropzone">Guardar</button>
        <button class="btn btn-secondary" type="reset">Cancelar</button>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('otika/assets/bundles/dropzonejs/min/dropzone.min.js'); ?>

<?php echo Html::script('otika/assets/js/page/multiple-upload.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/user/import.blade.php ENDPATH**/ ?>