
<?php $__env->startSection('title','Editar factura '.$invoice->id); ?>
<?php $__env->startSection('dropdown'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4>Editar factura</h4>
      </div>
      <?php echo Form::model($invoice, ['route'=>['backoffice.patient.invoices.update',$user,$invoice],'method'=>'PUT']); ?>

        <div class="card-body">
            

             
             
            

            <div class="form-group">
                <label>Monto de la factura</label>
                <?php echo Form::text('amount', null, ['class'=>'form-control']); ?>

                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="form-group">
                <label>Estatus</label>
                
                <select name="status" class="form-control">
                    <option value="pending"
                    <?php if($invoice->status == 'pending'): ?>
                        selected
                    <?php endif; ?>
                    >Pendiente</option>
                    <option value="approved"
                    <?php if($invoice->status == 'approved'): ?>
                    selected
                    <?php endif; ?>
                    >Pagado</option>
                    <option value="rejected"
                    <?php if($invoice->status == 'rejected'): ?>
                    selected
                    <?php endif; ?>
                    >Rechazado</option>
                    <option value="cancelled"
                    <?php if($invoice->status == 'cancelled'): ?>
                    selected
                    <?php endif; ?>
                    >Cancelado</option>
                    <option value="refunded"
                    <?php if($invoice->status == 'refunded'): ?>
                    selected
                    <?php endif; ?>
                    >Devolución</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            


        </div>
        <div class="card-footer text-right">
            <button class="btn btn-primary mr-1" type="submit">Actualizar</button>
            <a href="<?php echo e(route('backoffice.permissions.index')); ?>" class="btn btn-secondary" >Cancelar</a>
        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/invoice/edit.blade.php ENDPATH**/ ?>