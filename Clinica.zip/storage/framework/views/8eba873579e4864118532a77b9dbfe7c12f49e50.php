
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('name.user', $user->name); ?>
<?php $__env->startSection('dob.user', $user->age()); ?>
<?php $__env->startSection('email.user', $user->email); ?>
<?php $__env->startSection('date.user', $user->created_at->diffForHumans()); ?>
<?php $__env->startSection('title','Editar perfil'); ?>
<?php $__env->startSection('header','Editar perfil'); ?>
<?php $__env->startSection('nav'); ?>
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content.profile'); ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Actualizar datos de usuario</h3>
    </div>
    <?php echo Form::model($user, ['route'=>['frontoffice.user.update',$user->id, 'view=frontoffice'],'method'=>'PUT']); ?>

    <div class="card-body">
        <div class="from-group">
            <?php echo Form::label('name','Nombre de usuario'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control'],array('required' => 'required')); ?>

            <?php if($errors->has('name')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('name')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="from-group">
            <?php echo Form::label('dob','Fecha de nacimiento'); ?>

            <?php echo Form::date('dob', $user->dob->format('Y-m-d'), ['class'=>'form-control'],array('required' => 'required')); ?>

            <?php if($errors->has('dob')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('dob')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="from-group">
            <?php echo Form::label('email','Fecha de nacimiento'); ?>

            <?php echo Form::email('email', null, ['class'=>'form-control'],array('required' => 'required')); ?>

            <?php if($errors->has('email')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('email')); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-footer clearfix">
        <button type="submit" class="btn btn-primary float-right"><i class="far fa-paper-plane"></i>
            Actualizar</button>
    </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/user/edit.blade.php ENDPATH**/ ?>