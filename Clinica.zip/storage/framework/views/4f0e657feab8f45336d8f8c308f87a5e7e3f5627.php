
<?php $__env->startSection('title','Editar permiso '.$permission->name); ?>
<?php $__env->startSection('dropdown'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.permissions.index')); ?>">Permisos</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4>Editar permiso <?php echo e($permission->name); ?></h4>
      </div>
      <?php echo Form::model($permission, ['route'=>['backoffice.permissions.update',$permission],'method'=>'PUT']); ?>

        <div class="card-body">
            <?php echo $__env->make('admin.permission._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-footer text-right">
            <button class="btn btn-primary mr-1" type="submit">Actualizar</button>
            <a href="<?php echo e(route('backoffice.permissions.index')); ?>" class="btn btn-secondary" >Cancelar</a>
        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/permission/edit.blade.php ENDPATH**/ ?>