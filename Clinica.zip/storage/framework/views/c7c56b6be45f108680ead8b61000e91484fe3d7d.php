
<?php $__env->startSection('title','Agendar cita'); ?>
<?php $__env->startSection('styles'); ?>
<?php echo Html::style('pickadate/themes/default.css'); ?>

<?php echo Html::style('pickadate/themes/default.date.css'); ?>

<?php echo Html::style('pickadate/themes/default.time.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('dropdown'); ?>
<a class="dropdown-item has-icon" href="<?php echo e(route('backoffice.users.edit',$user)); ?>"><i class="fas fa-user-edit"></i>
    Editar usuario</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.index')); ?>">Usuarios</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-9 col-md-12 col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h4>Agendar cita</h4>
            </div>
            <?php echo Form::open(['route'=>['backoffice.patient.store_back_schedule', $user], 'method'=>'POST']); ?>

            <div class="card-body">
                <?php echo $__env->make('includes.user.patient.schedule_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-footer text-right">
                <div class="form-row">
                    <div class="col">
                        <button class="btn btn-primary float-right" type="submit">Agendar <i
                                class="far fa-paper-plane"></i></button>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
    <?php echo $__env->make('admin.user._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo $__env->make('includes.user.patient.schedule_foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/user/patient/schedule.blade.php ENDPATH**/ ?>