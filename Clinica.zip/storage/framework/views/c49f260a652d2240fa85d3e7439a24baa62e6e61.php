
<?php $__env->startSection('styles'); ?>
<?php echo Html::style('otika/assets/bundles/pretty-checkbox/pretty-checkbox.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Asignar roles'); ?>
<?php $__env->startSection('dropdown'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.index')); ?>">Usuarios</a></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.show',$user )); ?>"><?php echo e($user->name); ?></a></li>

<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    
    <div class="col-lg-9 col-md-12 col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h4>Selecciona los roles que deseas asignar</h4>
            </div>
            
            <?php echo Form::open(['route'=>['backoffice.role_assignment',$user], 'method'=>'POST']); ?>

            <div class="card-body">
                <div class="form-group">
                    <label>Roles</label> <br>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="pretty p-icon p-curve p-pulse">
                        <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" <?php if($user->has_role($role->id)): ?>
                            checked
                        <?php endif; ?>>
                        <div class="state p-info-o">
                            <i class="icon material-icons">done</i>
                            <label> <?php echo e($role->name); ?></label>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="card-footer text-right">
                <button class="btn btn-primary mr-1" type="submit">Guardar</button>
                <button class="btn btn-secondary" type="reset">Cancelar</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
    <?php echo $__env->make('admin.user._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/user/assign_role.blade.php ENDPATH**/ ?>