
<?php $__env->startSection('title','Detalles de rol'); ?>
<?php $__env->startSection('dropdown'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.roles.index')); ?>">Roles</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    
    <div class="col-12 col-md-6 col-lg-6">
        <div class="card">
            <div class="card-header">
                <h4>Detalles de rol <?php echo e($role->name); ?></h4>
            </div>
            <div class="card-body">
                <p><strong>Nombre: </strong><?php echo e($role->name); ?></p>
                <p><strong>Slug: </strong><?php echo e($role->slug); ?></p>
                <p><strong>Descripción: </strong><?php echo e($role->description); ?></p>
            </div>
            
        </div>

        

</div>

<div class="col-12 col-md-6 col-lg-6">
    <div class="card">
        <div class="card-header">
            <h4>Permisos</h4>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Descripción </th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($permission->id); ?></th>
                        <td><?php echo e($permission->name); ?></td>
                        <td><?php echo e($permission->description); ?></td>
                        <td>
                            <?php echo Form::open(['route'=>['backoffice.permissions.destroy',$permission->id],
                            'method'=>'DELETE', 'class'=>'formulario-eliminar']); ?>

                            <a href="<?php echo e(route('backoffice.permissions.edit', $permission->id)); ?>"
                                class="btn btn-icon btn-primary"><i class="far fa-edit"></i></a>

                            <button type="submit" class="btn btn-icon btn-danger"><i class="fas fa-trash"></i></button>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/role/show.blade.php ENDPATH**/ ?>