
<?php $__env->startSection('title','Registro de rol'); ?>
<?php $__env->startSection('dropdown'); ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.roles.index')); ?>">Roles</a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4>Crear rol</h4>
      </div>
      <?php echo Form::open(['route'=>'backoffice.roles.store', 'method'=>'POST']); ?>

        <div class="card-body">
            <?php echo $__env->make('admin.role._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-footer text-right">
            <button class="btn btn-primary mr-1" type="submit">Guardar</button>
            <button class="btn btn-secondary" type="reset">Cancelar</button>
        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/role/create.blade.php ENDPATH**/ ?>