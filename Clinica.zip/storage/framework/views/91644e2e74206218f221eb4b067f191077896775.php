<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">

    <title>Iniciar sesión</title>
    <!-- General CSS Files -->
    <?php echo Html::style('otika/assets/css/app.min.css'); ?>

    <?php echo Html::style('otika/assets/bundles/bootstrap-social/bootstrap-social.css'); ?>

    <!-- Template CSS -->
    <?php echo Html::style('otika/assets/css/style.css'); ?>

    <?php echo Html::style('otika/assets/css/components.css'); ?>

    <!-- Custom style CSS -->
    <?php echo Html::style('otika/assets/css/custom.css'); ?>

    <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />


</head>
<body>
    <div class="loader"></div>
    <div id="app">
        <section class="section">
            <div class="container mt-5">
                <div class="row">

                    <?php echo $__env->yieldContent('content'); ?>
                    
                </div>
            </div>
        </section>
    </div>

    <!-- General JS Scripts -->
    <?php echo Html::script('otika/assets/js/app.min.js'); ?>

    <!-- JS Libraies -->
    <!-- Page Specific JS File -->
    <!-- Template JS File -->
    <?php echo Html::script('otika/assets/js/scripts.js'); ?>

    <!-- Custom JS File -->
    <?php echo Html::script('otika/assets/js/custom.js'); ?>

</body>

        

    

</html>
<?php /**PATH C:\xampp\htdocs\Clinica\resources\views/layouts/app.blade.php ENDPATH**/ ?>