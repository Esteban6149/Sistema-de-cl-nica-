
<?php $__env->startSection('styles'); ?>
<?php echo Html::style('pickadate/themes/default.css'); ?>

<?php echo Html::style('pickadate/themes/default.date.css'); ?>

<?php echo Html::style('pickadate/themes/default.time.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('name.user', $user->name); ?>
<?php $__env->startSection('dob.user', $user->age()); ?>
<?php $__env->startSection('email.user', $user->email); ?>
<?php $__env->startSection('date.user', $user->created_at->diffForHumans()); ?>
<?php $__env->startSection('title','Citas'); ?>
<?php $__env->startSection('header','Citas'); ?>
<?php $__env->startSection('nav'); ?>
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content.profile'); ?>
<?php echo Form::open(['route'=>'frontoffice.patient.store_schedule', 'method'=>'POST']); ?>

    <?php echo $__env->make('includes.user.patient.schedule_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-row">
        <div class="col">
            <button class="btn btn-primary float-right" type="submit">Agendar <i
                    class="far fa-paper-plane"></i></button>
        </div>
    </div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo $__env->make('includes.user.patient.schedule_foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/patient/schedule.blade.php ENDPATH**/ ?>