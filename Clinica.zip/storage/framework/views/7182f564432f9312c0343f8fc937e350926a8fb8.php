

<?php $__env->startSection('styles'); ?>
<?php echo Html::style('pickadate/themes/default.css'); ?>

<?php echo Html::style('pickadate/themes/default.date.css'); ?>

<?php echo Html::style('pickadate/themes/default.time.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('name.user', $user->name); ?>
<?php $__env->startSection('dob.user', $user->age()); ?>
<?php $__env->startSection('email.user', $user->email); ?>
<?php $__env->startSection('date.user', $user->created_at->diffForHumans()); ?>
<?php $__env->startSection('title','Citas'); ?>
<?php $__env->startSection('header','Citas'); ?>
<?php $__env->startSection('nav'); ?>
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content.profile'); ?>

<form action="#" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-row">
        <div class="col">
            <label class="my-1 mr-2">Selecciona doctor</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text">
                        <i class="fas fa-user-md"></i>
                    </label>
                </div>
                <select name="doctor" class="custom-select">
                    <option selected>-- Seleccionar especialista --</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                </select>
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="col">
            <label for="datepiker">Seleccione una fecha</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        <i class="far fa-calendar-alt"></i>
                    </span>
                </div>
                <input type="text" name="date" class="datepiker form-control">
            </div>
        </div>
        <div class="col">
            <label for="timepiker">Seleccione un horario</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        <i class="far fa-clock"></i>
                    </span>
                </div>
                <input type="text" name="time" class="timepiker form-control">
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="col">
            <button class="btn btn-primary float-right" type="submit">Agendar  <i
                    class="far fa-paper-plane"></i></button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('pickadate/picker.js'); ?>

<?php echo Html::script('pickadate/picker.date.js'); ?>

<?php echo Html::script('pickadate/picker.time.js'); ?>

<?php echo Html::script('pickadate/legacy.js'); ?>

<script type="text/javascript">
   

    var input_date = $('.datepiker').pickadate({
        min: true
    });
    var date_piker = input_date.pickadate('picker');

    

    var input_time = $('.timepiker').pickatime({
        min: 4
    });
    var time_picker = input_time.pickatime('picker');

    

    $('select').formSelect();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/patient/cite.blade.php ENDPATH**/ ?>