

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name.user', $user->name); ?>
<?php $__env->startSection('dob.user', $user->age()); ?>
<?php $__env->startSection('email.user', $user->email); ?>
<?php $__env->startSection('date.user', $user->created_at->diffForHumans()); ?>
<?php $__env->startSection('title','Recetas'); ?>
<?php $__env->startSection('header','Recetas'); ?>
<?php $__env->startSection('nav'); ?>
<li class="nav-item">
    <a href="#" class="nav-link">Contact</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content.profile'); ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Historial de recetas</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table class="table ">
            <thead>
                <tr>
                    <th style="width: 10px">ID</th>
                    <th>Especialista</th>
                    <th>Acción </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Update software</td>
                    <td>
                        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default">
                            Ver
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
        
    </div>
</div>



<div class="modal fade" id="modal-default">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Large Modal</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <p>One fine body&hellip;</p>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <button type="button" class="btn btn-primary">Imprimir</button>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/frontoffice/patient/prescriptions.blade.php ENDPATH**/ ?>