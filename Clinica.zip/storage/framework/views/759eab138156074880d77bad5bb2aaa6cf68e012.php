<div class="col-lg-3 col-md-12 col-12 col-sm-12">
    <div class="list-group">
        <a href="<?php echo e(route('backoffice.users.show', $user->id)); ?>" class="list-group-item list-group-item-action active">
            <?php echo e($user->name); ?>

        </a>
        <?php if(Auth::user()->has_any_role([
            config('app.secretary_role'),
            config('app.admin_role'),
            config('app.doctor_role'),
            ])): ?>
            <?php if($user->has_role(config('app.patient_role'))): ?>
            
            

            <a href="<?php echo e(route('backoffice.clinic_data.index', $user)); ?>"
            class="list-group-item list-group-item-action">Historia clínica</a>

            

            <a href="<?php echo e(route('backoffice.patient.schedule', $user)); ?>"
            class="list-group-item list-group-item-action">Agendar cita</a>

            <a href="<?php echo e(route('backoffice.patient.appointments', $user)); ?>"
            class="list-group-item list-group-item-action">Citas</a>

            <a href="<?php echo e(route('backoffice.patient.invoices', $user)); ?>"
            class="list-group-item list-group-item-action">Facturas</a>

            <?php endif; ?>

            <?php if($user->has_role(config('app.doctor_role'))): ?>
            <a href="<?php echo e(route('backoffice.doctor.appointments.show', $user)); ?>"
            class="list-group-item list-group-item-action">Citas</a>
            
            <a href="<?php echo e(route('backoffice.doctor.schedule.assign', $user)); ?>"
            class="list-group-item list-group-item-action">Gestión de horarios</a>

            <?php endif; ?>

        <?php endif; ?>
        <?php if(Auth::user()->has_role(config('app.admin_role'))): ?>
        <a href="<?php echo e(route('backoffice.assign_role', $user)); ?>" class="list-group-item list-group-item-action">Asignar
            roles</a>
        <a href="<?php echo e(route('backoffice.assign_permission', $user)); ?>"
            class="list-group-item list-group-item-action">Asignar permisos</a>

            <?php if($user->has_role(config('app.doctor_role'))): ?>
            <a href="<?php echo e(route('backoffice.user.assign_speciality', $user)); ?>"
            class="list-group-item list-group-item-action">Asignar especialidad</a>
            <?php endif; ?>

        <?php endif; ?>
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/user/_menu.blade.php ENDPATH**/ ?>