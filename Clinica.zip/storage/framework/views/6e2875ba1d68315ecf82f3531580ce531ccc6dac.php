
<?php $__env->startSection('title','Historia clínica de '.$user->name); ?>
<?php $__env->startSection('dropdown'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.index')); ?>">Usuarios del sistema</a></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.users.show', $user)); ?>"><?php echo e($user->name); ?></a></li>
<li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-9 col-md-12 col-12 col-sm-12">
        <div class="row">
            <div class="col-lg-4 col-md-12 col-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Historia clínica</h4>
                    </div>
                    <div class="card-body">

                        <p><strong>Fecha de alta: </strong>
                            <?php echo e(carbon_format($user->clinic_data('check_in', $datas), 'd/m/Y')); ?></p>
                        <p><strong>Escolaridad: </strong><?php echo e($user->clinic_data('scholarship', $datas)); ?></p>

                    </div>
                    <div class="card-footer text-right">
                        <nav class="d-inline-block">

                        </nav>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-12 col-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Notas de evolución</h4>
                    </div>
                    <?php echo Form::open(['route'=>['backoffice.clinic_note.store', $user], 'method'=>'POST']); ?>

                    <div class="card-body">
                        <div class="form-group">
                            <label>Escribe la nota médica aquí</label>
                            <?php echo Form::textarea('description', null,['class'=>'form-control']); ?>

                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Selecciona la opción de privacidad</label>
                            <select class="form-control" id="privacy" name="privacy">
                                <option value="" disabled selected>Selecciona la opción de privacidad</option>
                                <option value="public">Pública</option>
                                <option value="private">Privada</option>
                            </select>

                            <?php $__errorArgs = ['privacy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="card-footer text-right">
                        <button class="btn btn-primary mr-1" type="submit">Guardar</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h4>Notas de evolución</h4>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                              <tr>
                                <th scope="col">Información</th>
                                <th scope="col">Acción</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $clinic_notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <p>Creado por <b><?php echo e($note->creator->name); ?></b> el
                                            <b><?php echo e(carbon_format($note->date, 'd/m/Y')); ?></b> a las
                                            <b><?php echo e(carbon_format($note->date, 'H:i')); ?></b></p>
                                        <b>Descripción: </b> <?php echo $note->description; ?>

                                    </td>
                                    <td>
                                        <p>

                                            <button 
                                                type="button" 
                                                class="btn btn-info" 
                                                data-toggle="modal"  
                                                data-target="#modal" 
                                                data-note="<?php echo e($note->id); ?>" 
                                                onclick="modal_note(this)"
                                            >Editar
                                            </button>

                                            

                                        </p>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2">No hay notas registradas</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer text-right">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.user._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    
    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="formModal"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formModal">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="modal_note_edit_form" action="" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>


                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea id="modal_note_description" name="description" class="form-control"></textarea>
                    </div>
                    <div class="row">
                        <div class="col s8">
                            <div class="form-group">
                                <select class="form-control" id="modal_note_privacy" name="privacy">
                                    <option value="public">Pública</option>
                                    <option value="private">Privada</option>
                                </select>
                            </div>
                        </div>
                        <div class="col s4">
                            <div class="row">
                                <div class="form-group col s12">
                                    <button class="btn btn-primary right" type="submit" style="width: 100%">
                                    <i class="fas fa-pen"></i>
                                    Actualizar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('otika/assets/bundles/jquery-ui/jquery-ui.min.js'); ?>

<!-- Page Specific JS File -->
<?php echo Html::script('otika/assets/js/page/advance-table.js'); ?>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script type="text/javascript">
 

    function modal_note(e)
    {
        var note_id = $(e).data('note');
        $.ajax({
            url: "<?php echo e(route('ajax.note_info')); ?>",
           
            data:
            {
                note_id: note_id,
            },
            success: function(data)
            {
                $("#modal_note_edit_form").attr('action', data.route);
                $("#modal_note_description").val(data.description);
                $("#modal_note_privacy").val(data.privacy);
                // re-initialize material-select DA UN ERROR
                   // $('#modal_note_privacy').material_select();
            }
        });
    }

</script>

<script>
    $('.formulario-eliminar').submit(function (e) {
        e.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        })
    });

</script>
<?php if(session('eliminar') == 'ok'): ?>
<script>
    Swal.fire(
        'Deleted!',
        'Your file has been deleted.',
        'success'
    )

</script>
<?php endif; ?>
<?php if(session('editado') == 'ok'): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Your work has been saved',
        showConfirmButton: false,
        timer: 1200
    })

</script>
<?php endif; ?>
<?php if(session('guardado') == 'ok'): ?>
<script>
    Swal.fire({

        icon: 'success',
        title: 'Your work has been saved',
        showConfirmButton: false,
        timer: 1200
    })

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/admin/user/patient/clinicdata/index.blade.php ENDPATH**/ ?>