<div class="form-row">
    <?php if(!isset($appointment)): ?>

        <?php if(user()->has_role(config('app.doctor_role'))): ?>
            <input type="hidden" name="doctor" value="<?php echo e(user()->id); ?>">
        <?php else: ?>
        <div class="col">
            <label class="my-1 mr-2">Selecciona la especialidad</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text">
                        <i class="fas fa-user-tag"></i>
                    </label>
                </div>
                <select name="speciality" id="speciality" class="custom-select">
                    <option selected>-- Seleccionar especialidad --</option>
                    <?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($speciality->id); ?>"><?php echo e($speciality->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col">
            <label class="my-1 mr-2">Selecciona doctor</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text">
                        <i class="fas fa-user-md"></i>
                    </label>
                </div>
                <select name="doctor" id="doctor" class="custom-select">
                    <option selected>-- Primero selecciona una especialidad --</option>
                    <option value="1">One</option>
                </select>
            </div>
        </div>
        <?php endif; ?>

    <?php else: ?>

    <div class="col">
        <label class="my-1 mr-2">Selecciona el estatus de la cita</label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <label class="input-group-text">
                    <i class="fas fa-clock"></i>
                </label>
            </div>
            <select name="status" id="status" class="custom-select">
                <option selected>-- Selecciona el estatus de la cita --</option>
                <option value="pending" 
                <?php if($appointment->status == 'pending'): ?>
                    selected
                <?php endif; ?>
                >Pendiente</option>
                <option value="done"
                <?php if($appointment->status == 'done'): ?>
                    selected
                <?php endif; ?>
                >Terminada</option>
                <option value="cancelled"
                <?php if($appointment->status == 'cancelled'): ?>
                    selected
                <?php endif; ?>
                >Cancelada</option>
            </select>
        </div>
    </div>
    <?php endif; ?>
</div>
<div class="form-row">
    <div class="col">
        <label for="datepiker">Seleccione una fecha</label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text">
                    <i class="far fa-calendar-alt"></i>
                </span>
            </div>
            <input type="text" name="date" class="datepiker form-control" 
            <?php if(isset($appointment)): ?>
                data-value="<?php echo e($appointment->date->format('Y-m-d')); ?>"
            <?php endif; ?>
            >
        </div>
    </div>
    <div class="col">
        <label for="timepiker">Seleccione un horario</label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text">
                    <i class="far fa-clock"></i>
                </span>
            </div>
            <input type="text" name="time" class="timepiker form-control"
            <?php if(isset($appointment)): ?>
                data-value="<?php echo e($appointment->date->format('H:i')); ?>"
            <?php endif; ?>
            >
        </div>
    </div>
</div>
<input type="hidden" name="user_id" value="<?php echo e(encrypt($user->id)); ?>"><?php /**PATH C:\xampp\htdocs\Clinica\resources\views/includes/user/patient/schedule_form.blade.php ENDPATH**/ ?>